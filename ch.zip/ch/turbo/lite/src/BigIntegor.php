<?php

namespace phpseclib\Math;

class BigIntegor
{
}
