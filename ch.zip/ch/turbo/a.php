<?php
date_default_timezone_set("Asia/Baghdad");
$info = json_decode(file_get_contents('info.json'),true);
define('API_KEY',$info['token']);
function bot($method,$datas=[]){
    $bot = http_build_query($datas);
        $url = "https://api.telegram.org/bot".API_KEY."/".$method."?$bot";
        $bots = file_get_contents($url);
        return json_decode($bots);
}
if (!file_exists('madeline.php')) {
 copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
define('MADELINE_BRANCH', 'deprecated');
include 'madeline.php';
use \danog\MadelineProto\Exception;
use \danog\MadelineProto\RPCErrorException;
function Ac($session) {
 $settings['app_info']['api_id'] = 579315;
 $settings['app_info']['api_hash'] = '4ace69ed2f78cec268dc7483fd3d3424';
 $settings['updates']['handle_updates'] = false;
 require 'lite/vendor/autoload.php';
 return new \danog\MadelineProto\API($session);
}
$settings['app_info']['api_id'] = 579315;
$settings['app_info']['api_hash'] = '4ace69ed2f78cec268dc7483fd3d3424';
$MadelineProto = new \danog\MadelineProto\API('m1.madeline', $settings);
$MadelineProto->start();
$x = 0;
$admin = $info['id'];
if(file_get_contents("users1") != ""){
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>" - I'm Run .",
]);
}
while(1){
    $users = explode("\n",file_get_contents("users1"));
    foreach($users as $user){
        if($user != ""){
            try{
            	$MadelineProto->messages->getPeerDialogs(['peers' => [$user], ]);
            $x++;
            }catch (\danog\MadelineProto\Exception | \danog\MadelineProto\RPCErrorException $e) {
                    try{
                        $MadelineProto->account->updateUsername(['username'=>$user]);
$send = "-FuckeD : @$user
-Loop's : $x
-by : تيم القرامه ";
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>$send
]);
system('pm2 stop a.php');
}catch (\danog\MadelineProto\Exception | \danog\MadelineProto\RPCErrorException $e) {
if($e->getMessage() == "The provided username is not valid"){
$data = str_replace("\n".$user,"", file_get_contents("users1"));
file_put_contents("users1", $data);
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"@$user ".$e->getMessage() 
]);
}elseif(preg_match('/FLOOD_WAIT_(.*)/i', $e->getMessage())){
$seconds = str_replace('FLOOD_WAIT_', '', $e->getMessage());
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>" I'm sleeping : ".$seconds]);
sleep($seconds);
}elseif($e->getMessage() == "USERNAME_OCCUPIED"){
$data = str_replace("\n".$user,"", file_get_contents("users1"));
file_put_contents("users1", $data);
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"@$user ".$e->getMessage() 
]);
}else{
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"@$user ".$e->getMessage() 
]);
}
}
  
                    }
	        }
        }
    }